﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] s1Scores = { 20, 19, 18 };
            Address ad1 = new Address("1000", "Rue des parchemins", "Montcuq", "France");
            Student s1 = new Student("AB45", "Sacha", "Weil", 20, ad1, s1Scores);


            Console.WriteLine("Student " + s1.FullName + " score is " + s1.AverageScore + "\n");

            Console.WriteLine("Student " + s1.FullName + " is living in " + s1.Addresss.City + "\n"); ;

            Console.WriteLine("Student " + s1.FullName + " address is " + s1.FullAddress + "\n");

            Console.WriteLine(s1);

            Console.ReadKey();
        }
    }
}
