﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Student : Person
    {
        public string studentNumber;
        public int age;
        public Address address;
        public string fullName;
        public int[] scores;
        public double averageScore;
        public string fullAddress;

        public Student(string studentNumber, string firstName, string lastName, int age, Address address, int[] scores) : base (firstName, lastName)
        {
            int counter = 0;
            int number = 0;

            this.studentNumber = studentNumber;
            this.fullName = firstName + ' ' + lastName;
            this.age = age;
            this.address = address;
            this.scores = scores;
            for(int i = 0; i < scores.Length; i++)
            {
                number += scores[i];
                counter++;
            }
            number /= counter;
            this.averageScore = number;

            this.fullAddress = address.Adress + " " + address.Street + " " + address.City + ", " + address.Country;

        }

        

        public string StudentNumber
        {
            get { return StudentNumber; }
            set { StudentNumber = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public Address Addresss
        {
            get { return address; }
            set { address = value; }
        }

        public string FullName
        {
            get { return fullName; }
            set { fullName = value; }
        }

        public int[] Scores
        {
            get { return scores; }
            set { scores = value; }
        }

        public double AverageScore
        {
            get { return averageScore; }
            set { averageScore = value; }
        }

        public string FullAddress
        {
            get { return fullAddress; }
            set { fullAddress = value; }
        }

        public override string ToString()
        {
            return "Student " + fullName + " average score is " + averageScore + "\n" + FullAddress;
        }
    }
}
