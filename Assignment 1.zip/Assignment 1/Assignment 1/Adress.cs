﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Address
    {
        public string adress;
        public string street;
        public string city;
        public string country;

        public Address(string adress, string street, string city, string country)
        {
            this.adress = adress;
            this.street = street;
            this.city = city;
            this.country = country;
        }

        public string Adress
        {
            get {return adress; }
            set { adress = value; }
        }

        public string Street
        {
            get { return street; }
            set { street = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string Country
        {
            get { return country; }
            set { country = value; }
        }
    }
}
